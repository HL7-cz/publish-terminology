# Home - HL7 Czech Terminology Implementation Guide v0.2.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://hl7.cz/terminology/ImplementationGuide/hl7.fhir.cz.terminology | *Version*:0.2.0 |
| Active as of 2025-12-23 | *Computable Name*:HL7CzTerminologyImplementationGuide |

### Scope

### Introduction

### Dependencies




### Cross Version Analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (hl7.fhir.cz.terminology.r4)](package.r4.tgz) and [R4B (hl7.fhir.cz.terminology.r4b)](package.r4b.tgz) are available.

### Global Profiles

*There are no Global profiles defined*

### IP Statements

This publication includes IP covered under the following statements.

* ISO Maintains the copyright on the country codes, and controls it's use carefully. For futher details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/5.0.0/CodeSystem-ISO3166Part1.html): [AbsentAndUnknownDataUvIps](CodeSystem-absent-unknown-uv-ips-cz.md), [AdministrativeGenderCz](CodeSystem-administrative-gender-cz.md)...Show 55 more,[AdministrativeGenderCzVs](ValueSet-administrative-gender-cz.md),[AllergenWithExceptions](ValueSet-AllergenWithExceptions.md),[AllergyIntoleranceCategory](ValueSet-allergy-intolerance-category-cz.md),[AllergyIntoleranceCriticality](ValueSet-allergy-intolerance-criticality-cz.md),[CS_DLP_atc](CodeSystem-dlp-atc.md),[CS_DLP_formy](CodeSystem-dlp-formy.md),[CS_DLP_lecivelatky](CodeSystem-dlp-lecivelatky.md),[CS_DLP_lecivepripravky](CodeSystem-dlp-lecivepripravky.md),[CS_Drzar](CodeSystem-drzar.md),[CS_HealthInsuranceCompanyCode](CodeSystem-healthInsuranceCompanyCode.md),[CZ_CoverageType](ValueSet-cz-coverage-type.md),[CZ_LateralityVs](ValueSet-cz-specimen-laterality.md),[CZ_LogoMimeTypesVs](ValueSet-cz-logo-mime-types.md),[CZ_SiteQualifier](ValueSet-cz-sitequalifier.md),[CZ_SpecimenAdditive](ValueSet-cz-specimenAdditive.md),[CZ_SpecimenContainer](ValueSet-cz-specimencontainer.md),[ConditionVS](ValueSet-condition-cz.md),[ContactRole2Cz](CodeSystem-v2-0131-cz.md),[CoverageSelfPayCodesCZ](CodeSystem-coverage-selfpay-cz.md),[DLP_atc](ValueSet-dlp-atc.md),[DLP_formy](ValueSet-dlp-formy.md),[DLP_lecivelatky](ValueSet-dlp-lecivelatky.md),[DLP_lecivepripravky](ValueSet-dlp-lecivepripravky.md),[DocumentCategory](ValueSet-document-category.md),[Drzar](ValueSet-drzar.md),[EHDSIAbsentOrUnknownAllergyCZ](ValueSet-eHDSIAbsentOrUnknownAllergy-cz.md),[EHDSIAbsentOrUnknownDeviceCZ](ValueSet-eHDSIAbsentOrUnknownDevice-cz.md),[EHDSIAllergenNoDrugCZ](ValueSet-eHDSIAllergenNoDrug-cz.md),[EHDSIExceptionalValueCZ](ValueSet-eHDSIExceptionalValue-cz.md),[HL7CzTerminologyImplementationGuide](index.md),[HealthInsuranceCompanyCode](ValueSet-healthInsuranceCompanyCode.md),[Hl7vsContactAndRelationshipCz100](ValueSet-contact-and-relationship-cz.md),[Hl7vs_contactrole_cz](ValueSet-contactrole-cz.md),[ImagingDocumentTypes](ValueSet-imaging-document-types.md),[LabDocumentTypes](ValueSet-lab-document-types.md),[LabSpecimentype](ValueSet-lab-specimenType.md),[MKN10_5](CodeSystem-mkn-10.md),[MedicalDeviceVS](ValueSet-medical-device.md),[MedicalDeviceWithExceptionsVS](ValueSet-MedicalDeviceWithExceptions.md),[MedicalDocumentType](ValueSet-medical-document-type.md),[Mkn105](ValueSet-mkn-10.md),[NCLPMAT](CodeSystem-nclp-NCLPMAT.md),[NCLPMatVs](ValueSet-nclpmat.md),[NRZP_Povolani](CodeSystem-nrzp-povolani.md),[NRZP_PovolaniVS](ValueSet-nrzp-povolani-vs.md),[NullFlavor](CodeSystem-v3-NullFlavor-cz.md),[NursingDocumentType](ValueSet-nursing-document-type.md),[OPNSVS](ValueSet-OP-NS.md),[PassportNSVS](ValueSet-passport-NS.md),[PersonalRelationshipCzVS](ValueSet-personal-relationship-cz.md),[ReferralorderTypes](ValueSet-referralorder-types.md),[RegisteringProviderServiceTypeCz](ValueSet-registering-provider-service-type-cz.md),[RoleCodeCz](CodeSystem-v3-RoleCode-cz.md),[SearchDocumentTypes](ValueSet-search-document-types.md)and[v3-ActCode](CodeSystem-v3-ActCode-cz.md)


* Produced by HL7 under the terms of HL7® Governance and Operations Manual relating to Intellectual Property (Section 16), specifically its copyright, trademark and patent provisions. This document is licensed under Creative Commons "No Rights Reserved" (CC0).

* [Absent and Unknown Data - IPS](http://hl7.org/fhir/uv/ips/STU1.1/CodeSystem-absent-unknown-uv-ips.html): [EHDSIAbsentOrUnknownAllergyCZ](ValueSet-eHDSIAbsentOrUnknownAllergy-cz.md) and [EHDSIAbsentOrUnknownDeviceCZ](ValueSet-eHDSIAbsentOrUnknownDevice-cz.md)
* [Absent and Unknown Data - IPS](http://hl7.org/fhir/uv/ips/STU1.1/CodeSystem-absent-unknown-uv-ips.html): [AbsentAndUnknownDataUvIps](CodeSystem-absent-unknown-uv-ips-cz.md)


* This material contains content from [LOINC](http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the [license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

* [LOINC](http://terminology.hl7.org/5.0.0/CodeSystem-v3-loinc.html): [DocumentCategory](ValueSet-document-category.md), [ImagingDocumentTypes](ValueSet-imaging-document-types.md)...Show 4 more,[LabDocumentTypes](ValueSet-lab-document-types.md),[MedicalDocumentType](ValueSet-medical-document-type.md),[NursingDocumentType](ValueSet-nursing-document-type.md)and[ReferralorderTypes](ValueSet-referralorder-types.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://tx.fhir.org/r4/ValueSet/snomedct): [CZ_LateralityVs](ValueSet-cz-specimen-laterality.md), [CZ_SiteQualifier](ValueSet-cz-sitequalifier.md)...Show 8 more,[CZ_SpecimenAdditive](ValueSet-cz-specimenAdditive.md),[CZ_SpecimenContainer](ValueSet-cz-specimencontainer.md),[ConditionVS](ValueSet-condition-cz.md),[EHDSIAllergenNoDrugCZ](ValueSet-eHDSIAllergenNoDrug-cz.md),[LabSpecimentype](ValueSet-lab-specimenType.md),[MedicalDeviceVS](ValueSet-medical-device.md),[ReferralorderTypes](ValueSet-referralorder-types.md)and[RegisteringProviderServiceTypeCz](ValueSet-registering-provider-service-type-cz.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [Coverage SelfPay Codes](http://terminology.hl7.org/7.0.1/CodeSystem-coverage-selfpay.html): [CZ_CoverageType](ValueSet-cz-coverage-type.md)
* [Coverage SelfPay Codes](http://terminology.hl7.org/7.0.1/CodeSystem-coverage-selfpay.html): [CoverageSelfPayCodesCZ](CodeSystem-coverage-selfpay-cz.md)
* [contactRole2](http://terminology.hl7.org/7.0.1/CodeSystem-v2-0131.html): [Hl7vs_contactrole_cz](ValueSet-contactrole-cz.md)
* [contactRole2](http://terminology.hl7.org/7.0.1/CodeSystem-v2-0131.html): [ContactRole2Cz](CodeSystem-v2-0131-cz.md)
* [ActCode](http://terminology.hl7.org/7.0.1/CodeSystem-v3-ActCode.html): [CZ_CoverageType](ValueSet-cz-coverage-type.md)
* [ActCode](http://terminology.hl7.org/7.0.1/CodeSystem-v3-ActCode.html): [v3-ActCode](CodeSystem-v3-ActCode-cz.md)
* [NullFlavor](http://terminology.hl7.org/7.0.1/CodeSystem-v3-NullFlavor.html): [EHDSIExceptionalValueCZ](ValueSet-eHDSIExceptionalValue-cz.md)
* [NullFlavor](http://terminology.hl7.org/7.0.1/CodeSystem-v3-NullFlavor.html): [NullFlavor](CodeSystem-v3-NullFlavor-cz.md)
* [RoleCode](http://terminology.hl7.org/7.0.1/CodeSystem-v3-RoleCode.html): [PersonalRelationshipCzVS](ValueSet-personal-relationship-cz.md)
* [RoleCode](http://terminology.hl7.org/7.0.1/CodeSystem-v3-RoleCode.html): [RoleCodeCz](CodeSystem-v3-RoleCode-cz.md)


* Unless otherwise indicated, reproduction of material posted on Council of Europe websites, and reproduction of photographs for which the Council of Europe holds copyright – see legal notice \“photo credits\” – is authorised for private use and for informational and educational uses relating to the Council of Europe’s work. This authorisation is subject to the condition that the source be indicated and no charge made for reproduction. Persons wishing to make some other use than those specified above, including commercial use, of information and text posted on these sites are asked to apply for prior written authorisation to the Council of Europe, Directorate of Communication.

* [EDQM Standard Terms](http://tx.fhir.org/r4/ValueSet/edqm): [CS_DLP_formy](CodeSystem-dlp-formy.md)


