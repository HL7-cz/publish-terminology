# Role code (CZ) - HL7 Czech Terminology Implementation Guide v0.3.0

## ValueSet: Role code (CZ) 

 
Vztah kontaktní osoby k subjektu. (Relationship between subject and contact person.) 

 **References** 

* Included into [Hl7vsContactAndRelationshipCz100](ValueSet-contact-and-relationship-cz.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "personal-relationship-cz",
  "language" : "cs",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/valueset-supplement",
    "valueCanonical" : "https://hl7.cz/terminology/CodeSystem/v3-RoleCode-cz"
  }],
  "url" : "https://hl7.cz/terminology/ValueSet/personal-relationship-cz",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:1.2.203.24341.11.1.8"
  }],
  "version" : "1.0.0",
  "name" : "PersonalRelationshipCzVS",
  "title" : "Role code (CZ)",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-03-03T12:31:40.515581Z",
  "publisher" : "HL7 Czech Republic",
  "contact" : [{
    "name" : "HL7 Czech Republic",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.hl7.cz/"
    }]
  }],
  "description" : "Vztah kontaktní osoby k subjektu. (Relationship between subject and contact person.)",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "CZ",
      "display" : "Czechia"
    }]
  }],
  "copyright" : "HL7",
  "compose" : {
    "include" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleCode",
      "version" : "4.0.0",
      "concept" : [{
        "code" : "NOK"
      },
      {
        "code" : "FAMMEMB"
      },
      {
        "code" : "FRND"
      },
      {
        "code" : "NBOR"
      },
      {
        "code" : "DAUFOST"
      },
      {
        "code" : "AUNT"
      },
      {
        "code" : "GRNDSON"
      },
      {
        "code" : "GRMTH"
      },
      {
        "code" : "DOMPART"
      },
      {
        "code" : "DAUADOPT"
      },
      {
        "code" : "SONINLAW"
      },
      {
        "code" : "NIENEPH"
      },
      {
        "code" : "UNCLE"
      },
      {
        "code" : "GGRFTH"
      },
      {
        "code" : "BROINLAW"
      },
      {
        "code" : "CHLDFOST"
      },
      {
        "code" : "DAUC"
      },
      {
        "code" : "SONC"
      },
      {
        "code" : "STPCHLD"
      },
      {
        "code" : "DAUINLAW"
      },
      {
        "code" : "COUSN"
      },
      {
        "code" : "SON"
      },
      {
        "code" : "SPS"
      },
      {
        "code" : "CHLDADOPT"
      },
      {
        "code" : "NCHILD"
      },
      {
        "code" : "SIGOTHR"
      },
      {
        "code" : "GGRMTH"
      },
      {
        "code" : "MTH"
      },
      {
        "code" : "MTHINLAW"
      },
      {
        "code" : "BRO"
      },
      {
        "code" : "HUSB"
      },
      {
        "code" : "PRN"
      },
      {
        "code" : "SIB"
      },
      {
        "code" : "NIECE"
      },
      {
        "code" : "FTH"
      },
      {
        "code" : "FTHINLAW"
      },
      {
        "code" : "STPSON"
      },
      {
        "code" : "SONFOST"
      },
      {
        "code" : "GGRPRN"
      },
      {
        "code" : "GRNDCHILD"
      },
      {
        "code" : "EXT"
      },
      {
        "code" : "SISINLAW"
      },
      {
        "code" : "WIFE"
      },
      {
        "code" : "DAU"
      },
      {
        "code" : "GRPRN"
      },
      {
        "code" : "CHILD"
      },
      {
        "code" : "GRNDDAU"
      },
      {
        "code" : "GRFTH"
      },
      {
        "code" : "PRNINLAW"
      },
      {
        "code" : "ROOM"
      },
      {
        "code" : "CHLDINLAW"
      },
      {
        "code" : "SONADOPT"
      },
      {
        "code" : "STPDAU"
      },
      {
        "code" : "NEPHEW"
      },
      {
        "code" : "SIS"
      }]
    }]
  }
}

```
