# eHDSI Exceptional Value - HL7 Czech Terminology Implementation Guide v0.3.0

## ValueSet: eHDSI Exceptional Value 

 
The Value Set is used to code exceptional values for the required binding in FHIR IGs 

 **References** 

* Included into [AllergenWithExceptions](ValueSet-AllergenWithExceptions.md)
* Included into [MedicalDeviceWithExceptionsVS](ValueSet-MedicalDeviceWithExceptions.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "eHDSIExceptionalValue",
  "language" : "cs",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 2
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "trial-use"
  }],
  "url" : "https://ncez.mzcr.cz/terminology/ValueSet/eHDSIExceptionalValue",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:1.3.6.1.4.1.12559.11.10.1.3.1.42.81"
  }],
  "version" : "0.0.1",
  "name" : "EHDSIExceptionalValue",
  "title" : "eHDSI Exceptional Value",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-07-27T16:55:21+02:00",
  "publisher" : "HL7 Czech Republic",
  "contact" : [{
    "name" : "HL7 Czech Republic",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.hl7.cz/"
    }]
  }],
  "description" : "The Value Set is used to code exceptional values for the required binding in FHIR IGs",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "CZ",
      "display" : "Czechia"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-NullFlavor",
      "version" : "4.0.0",
      "concept" : [{
        "code" : "OTH",
        "display" : "jinak"
      },
      {
        "code" : "UNC",
        "display" : "nekódováno"
      },
      {
        "code" : "UNK",
        "display" : "není známo"
      }]
    }]
  }
}

```
